package libGraph;

import libGraph.util.DuplicateElementException;
import libGraph.util.ElementNotFoundException;
import libGraph.util.EmptyLinkedListException;

/**
 * Created by Mohammed Alshehry, 201138010 on 5/5/14.
 */
public class Test {
    public static void main(String[] args) throws EmptyLinkedListException, ElementNotFoundException, DuplicateElementException {
        DirectedGraph<String> g = new DirectedGraph<String>();

        String a = new String("A");

        g.addVertex(a);
        g.addVertex("B");
        g.addVertex("C");
        g.addVertex("D");
        g.addVertex("E");
        g.addVertex("F");
        g.addVertex("G");
        g.addVertex("H");
        g.addVertex("I");

        g.addEdge("A", "B");
        g.addEdge("A", "C");
        g.addEdge("A", "E");
        g.addEdge("B", "D");
        g.addEdge("B", "E");
        g.addEdge("C", "F");
        g.addEdge("C", "H");
        g.addEdge("D", "G");
        g.addEdge("F", "H");
        g.addEdge("E", "G");
        g.addEdge("E", "H");
        g.addEdge("E", "I");
        g.addEdge("G", "I");
        g.addEdge("H", "I");

        g.topologicalSort();
    }
}
