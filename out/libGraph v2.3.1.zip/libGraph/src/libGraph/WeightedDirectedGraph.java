package libGraph;

import libGraph.util.DuplicateElementException;
import libGraph.util.ElementNotFoundException;
import libGraph.util.LinkedList;
import libGraph.util.LinkedListNode;

/**
 * Created by Mohammed Alshehry, 201138010 on 5/7/14.
 */
public class WeightedDirectedGraph<T extends Comparable> extends DirectedGraph<T> {

    public WeightedDirectedGraph() {
        super();
    }

    public void addEdge(T from, T to, double weight) throws ElementNotFoundException, DuplicateElementException {
        Vertex<T> v1 = vertices.find(new Vertex<T>(from));
        Vertex<T> v2 = vertices.find(new Vertex<T>(to));

        v1.addEdge(new WeightedEdge<T>(v1, v2, weight));
    }

    public void DijkstraShortestPath(T data) throws ElementNotFoundException, DuplicateElementException {
        Graph<T> g = new Graph<T>(this);
        Vertex<T> s = g.vertices.find(new Vertex<T>(data));

        LinkedList<WeightedEdge<T>> tmp = new LinkedList<WeightedEdge<T>>();
        for(LinkedListNode<Vertex<T>> p = g.vertices.getHead().getNext(); p != null; p = p.getNext()) {
            tmp.add(new WeightedEdge<T>(g.vertices.getHead().getData(), p.getData(), Double.POSITIVE_INFINITY));
        }

        while(!g.isEmpty()) {
            WeightedEdge<T> min = s.edges.getHead();
            for(LinkedListNode<WeightedEdge<T>> e = s.edges.getHead(); e != null; e = e.getNext()) {

            }
        }

    }


}
