package libGraph;


/**
 * Created by fcm2009 on 4/28/14.
 */
public class Edge<T extends Comparable> implements Comparable {

    protected Vertex<T> from;
    protected Vertex<T> to;

    public Edge(Vertex<T> from, Vertex<T> to) {
        this.from = from;
        this.to = to;
    }

    public Edge() {
        this(null, null);
    }

    public boolean links(Vertex<T> v) {
        if(v == null)
            throw new IllegalArgumentException();
        else if(v.compareTo(from) == 0 || v.compareTo(to) == 0)
            return true;
        else
            return false;
    }

    public String toString() {
        return "Linkes: " + from.data.toString() + " and: " + to.data.toString();
    }

    public int compareTo(Object obj) {
        if(obj != null) {
            if(obj.getClass() == getClass()) {
                Edge<T> e = (Edge<T>) obj;
                if(from.compareTo(e.to) == 0)
                    return to.compareTo(e.from);
                else if(from.compareTo(e.from) == 0)
                    return to.compareTo(e.to);
                else
                    return from.compareTo(e.from);
            }
            else
                throw new ClassCastException();
        }
        else
            throw new NullPointerException();
    }

    public boolean equals(Object obj) {
        return compareTo(obj) == 0;
    }

}
