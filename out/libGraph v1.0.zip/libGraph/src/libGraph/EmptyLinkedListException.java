package libGraph;

public class EmptyLinkedListException extends Exception {

    public EmptyLinkedListException(String message) {
    	super(message);
    }

    public EmptyLinkedListException() {
    	this("Linked List is Empty");
    }
}