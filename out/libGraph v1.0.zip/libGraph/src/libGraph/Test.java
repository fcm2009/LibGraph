package libGraph;

public class Test {
    public static void main(String[] args) throws EmptyLinkedListException, ElementNotFoundException, DuplicateElementException{
        Graph<String> g = new Graph<String>();

        g.addVertex("A");
        g.addVertex("B");
        g.addVertex("C");
        g.addVertex("D");
        g.addVertex("E");
        g.addVertex("F");
        g.addVertex("G");
        g.addVertex("H");
        g.addVertex("I");

        g.addEdge("A", "B");
        g.addEdge("A", "D");
        g.addEdge("A", "E");
        g.addEdge("B", "C");
        g.addEdge("B", "E");
        g.addEdge("C", "F");
        g.addEdge("D", "G");
        g.addEdge("E", "G");
        g.addEdge("G", "H");
        g.addEdge("H", "I");

        System.out.println("**************************************************************************");

        g.breadthFirst();
    }
}
