package libGraph;

/**
 * Created by fcm2009 on 5/1/14.
 */
public class ElementNotFoundException extends Exception {

    public ElementNotFoundException(String message) {
        super(message);
    }

    public ElementNotFoundException() {
        this("Element Is Not Found");
    }
}
