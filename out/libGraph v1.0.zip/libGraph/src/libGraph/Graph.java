package libGraph;

public class Graph<T extends Comparable> {

    protected LinkedList<Vertex<T>> vertices;

    public Graph() {
        vertices = new LinkedList<Vertex<T>>();
    }

    public void addVertex(T data) throws DuplicateElementException {
        vertices.add(new Vertex<T>(data));
    }

    public void addEdge(T from, T to) throws ElementNotFoundException, DuplicateElementException {
        Vertex <T> v1 = vertices.find(new Vertex<T>(from));
        Vertex <T> v2 = vertices.find(new Vertex<T>(to));
        Edge<T> e1 = new Edge<T>(v1, v2);
        Edge<T> e2 = new Edge<T>(v2, v1);

        v1.addEdge(e1);
        v2.addEdge(e2);
    }

    public void deleteVertex(T data) throws ElementNotFoundException, EmptyLinkedListException {
        vertices.delete(new Vertex<T>(data));
        boolean flage = true;

        for(LinkedListNode<Vertex<T>> p = vertices.head; p != null; p = p.next) {
                try {
                    p.data.deleteEdge(new Edge<T>(p.data, new Vertex<T>(data)));
                    flage = false;
                }
                catch(ElementNotFoundException e){}
        }
        if(flage)
            throw new ElementNotFoundException();

    }

    public void deleteEdge(T from, T to) throws ElementNotFoundException, EmptyLinkedListException {
        boolean flage = true;
        for(LinkedListNode<Vertex<T>> p = vertices.head; p != null; p = p.next)
            try{
                p.data.deleteEdge(new Edge<T>(new Vertex<T>(from), new Vertex<T>(to)));
                flage = false;
            }
            catch(ElementNotFoundException e) {}

        if(flage)
            throw new ElementNotFoundException();
    }

    public void preOrder() {
        preOrder(vertices.head.data);
    }

    private void preOrder(Vertex<T> v) {
        if(!v.isVisited()) {
            System.out.println(v);
            v.markVisited();
            for(LinkedListNode<Edge<T>> p = v.edges.head; p != null; p = p.next) {
                if(!p.data.to.visited)
                    preOrder(p.data.to);
            }
        }
    }   //CHANGE RETURN TYPE TO STRING

    public void postOrder() {
        postOrder(vertices.head.data);
    }

    private void postOrder(Vertex<T> v) {
        if(!v.isVisited()) {
            v.markVisited();
            for(LinkedListNode<Edge<T>> p = v.edges.head; p != null; p = p.next) {
                if(!p.data.to.isVisited())
                    postOrder(p.data.to);
            }
            System.out.println(v);
        }
    }   //CHANGE RETURN TYPE TO STRING

    public void breadthFirst() throws DuplicateElementException, ElementNotFoundException, EmptyLinkedListException {
        Queue<Vertex<T>> q = new Queue<Vertex<T>>();
        try {
            q.enqueue(vertices.head.data);
            while(!q.isEmpty()) {
                Vertex<T> v = q.dequeue();
                System.out.print(v);
                v.markVisited();
                for(LinkedListNode<Edge<T>> p = v.edges.head; p != null; p = p.next) {
                    if(!p.data.to.isVisited()) {
                        q.enqueue(p.data.to);
                    }
                }
            }
        }
        catch(DuplicateElementException e) {throw new FatalErrorException();}
        catch(ElementNotFoundException e) {throw new FatalErrorException();}
        catch(EmptyLinkedListException e) {throw new FatalErrorException();}
    }

    public String toString() {
        return vertices.toString();
    }

}
