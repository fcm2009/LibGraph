package libGraph;

/**
 * Created by fcm2009 on 4/28/14.
 */
public class Vertex<T extends Comparable> implements Comparable {

    protected T data;
    protected LinkedList<Edge<T>> edges;
    protected boolean visited;

    public Vertex(T data) {
        edges = new LinkedList<Edge<T>>();
        this.data = data;
        visited = false;
    }

    public Vertex() {
        this(null);
    }

    public void addEdge(Edge<T> e) throws DuplicateElementException {
        edges.add(e);
    }

    public void deleteEdge(Edge<T> e) throws ElementNotFoundException, EmptyLinkedListException {
        edges.delete(e);
    }

    public Edge<T> isAdjasentTo(Vertex<T> v) {
        if(v == null)
            throw new IllegalArgumentException();

        LinkedListNode<Edge<T>> p;
        for(p = edges.head; p != null && !p.data.links(v); p = p.next);
        return (p == null) ? null:p.data;
    }

    public int outDig() {
        return edges.length();
    }

    public void markVisited() {
        visited = true;
    }

    public boolean isVisited() {
        return visited == true;
    }

    public String toString() {
        return data.toString() + "\n" + edges.toString();
    }

    public int compareTo(Object obj) {
        if(obj != null) {
            if(obj.getClass() == getClass()) {
                Vertex<T> v = (Vertex<T>) obj;
                return data.compareTo(v.data);
            }
            else
                throw new ClassCastException();
        }
        else
            throw new NullPointerException();
    }

    public boolean equals(Object obj) {
        return compareTo(obj) == 0;
    }
}
