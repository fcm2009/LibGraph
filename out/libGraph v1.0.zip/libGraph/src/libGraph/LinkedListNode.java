package libGraph;

/**
 * Created by fcm2009 on 4/28/14.
 */
public class LinkedListNode<T extends Comparable> implements Comparable<T> {

    protected LinkedListNode<T> next;
    protected T data;

    public LinkedListNode(T data, LinkedListNode<T> next) {
        this.data = data;
        this.next = next;
    }

    public LinkedListNode(T data) {
        this.data = data;
    }

    public LinkedListNode() {
        this(null, null);
    }

    public String toString() {
        return data.toString();
    }

    public int compareTo(T data) {
        if(data != null) {
            return this.data.compareTo(data);
        }
        else
            throw new NullPointerException();
    }
}
